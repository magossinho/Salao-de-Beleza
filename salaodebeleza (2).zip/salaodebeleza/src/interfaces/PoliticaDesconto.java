package interfaces;

public interface PoliticaDesconto {

	public Double gerarPercentualDeDesconto(Double valor);
	
}
